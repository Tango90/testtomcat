package com.javasampleapproach.angular6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegrateSpringBootRestApiAngular6Application {

	public static void main(String[] args) {
		SpringApplication.run(IntegrateSpringBootRestApiAngular6Application.class, args);
	}
}
